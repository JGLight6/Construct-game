const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.DragnDrop,
		C3.Behaviors.Pin,
		C3.Plugins.Text,
		C3.Plugins.TextBox,
		C3.Plugins.TiledBg,
		C3.Plugins.Mouse,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.TextBox.Cnds.CompareText,
		C3.Plugins.System.Cnds.TriggerOnce,
		C3.Behaviors.DragnDrop.Acts.SetEnabled,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.TextBox.Acts.SetEnabled,
		C3.Plugins.Sprite.Cnds.IsOverlappingOffset,
		C3.Behaviors.Pin.Acts.PinByImagePoint,
		C3.Plugins.Sprite.Cnds.IsOverlapping
	];
};
self.C3_JsPropNameTable = [
	{ArrastrarYSoltar: 0},
	{Pegado: 0},
	{Placa_base: 0},
	{ATX_Case: 0},
	{psu: 0},
	{ram: 0},
	{cpu_cooler: 0},
	{cpu: 0},
	{Grafica: 0},
	{Texto: 0},
	{EntradaDeTextoCPU: 0},
	{EntradaDeTextoPlaca: 0},
	{EntradaDeTextoPSU: 0},
	{EntradaDeTextoRAm: 0},
	{EntradaDeTextoCPU_cooler: 0},
	{EntradaDeTextoGPU: 0},
	{FondoEnMosaico: 0},
	{Mouse: 0},
	{Texto2: 0},
	{comprobadorPlacaBase: 0},
	{ComprobadorPSU: 0},
	{Aciertos: 0}
];

self.InstanceType = {
	Placa_base: class extends self.ISpriteInstance {},
	ATX_Case: class extends self.ISpriteInstance {},
	psu: class extends self.ISpriteInstance {},
	ram: class extends self.ISpriteInstance {},
	cpu_cooler: class extends self.ISpriteInstance {},
	cpu: class extends self.ISpriteInstance {},
	Grafica: class extends self.ISpriteInstance {},
	Texto: class extends self.ITextInstance {},
	EntradaDeTextoCPU: class extends self.ITextInputInstance {},
	EntradaDeTextoPlaca: class extends self.ITextInputInstance {},
	EntradaDeTextoPSU: class extends self.ITextInputInstance {},
	EntradaDeTextoRAm: class extends self.ITextInputInstance {},
	EntradaDeTextoCPU_cooler: class extends self.ITextInputInstance {},
	EntradaDeTextoGPU: class extends self.ITextInputInstance {},
	FondoEnMosaico: class extends self.ITiledBackgroundInstance {},
	Mouse: class extends self.IInstance {},
	Texto2: class extends self.ITextInstance {},
	comprobadorPlacaBase: class extends self.ISpriteInstance {},
	ComprobadorPSU: class extends self.ISpriteInstance {}
}